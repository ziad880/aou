import socket
for port in range(1, 65535):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = s.connect_ex(('192.168.0.1', port))  # فحص المنافذ
    print(result)
    if result == 0:
        print(f"Port {port} is open")
        break
